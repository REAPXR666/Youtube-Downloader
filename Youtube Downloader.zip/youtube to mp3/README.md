███████████████████████████████████████████████████████████████████████
█▄─▀█▀─▄██▀▄─██▄─▄▄▀█▄─▄▄─███▄─▄─▀█▄─█─▄███▄─▄███─▄▄─█▄─██─▄█▄─▄█─▄▄▄▄█
██─█▄█─███─▀─███─██─██─▄█▀████─▄─▀██▄─▄█████─██▀█─██─██─██─███─██▄▄▄▄─█
▀▄▄▄▀▄▄▄▀▄▄▀▄▄▀▄▄▄▄▀▀▄▄▄▄▄▀▀▀▄▄▄▄▀▀▀▄▄▄▀▀▀▀▄▄▄▄▄▀▄▄▄▄▀▀▄▄▄▄▀▀▄▄▄▀▄▄▄▄▄▀

*NOTES
Made by Louis
Built in just under a day
Enjoy using!

*STATUS
-audio converter - Working
-video converter - Working

*UPDATE
-added in Video Downloader
-added in Audio Quality changer (mp3 always sounds the same quality)
-Can change file formats
-Displays Video Link in "Video Link.txt"
-Easier to use
-Better UI

*REQUIREMENTS
pip install youtube_dl
pip install youtube
pip install pytube

*WEBSITE
https://louisgaming.co.uk




